## About

This is an example of integrating a PHP application with the Jenkins PHP template (http://jenkins-php.org/). 
Read more at http://systemsarchitect.net/continuous-integration-for-php-with-jenkins/

## Installation

```
php composer.phar install
```

```
sudo vendor/bin/phing install
```


