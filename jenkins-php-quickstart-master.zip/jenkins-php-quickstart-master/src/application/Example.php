<?php

class Example {
	
	public function foo() {
		return 'bar';
	}
	
}